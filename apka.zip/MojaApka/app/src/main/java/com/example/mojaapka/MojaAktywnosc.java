package com.example.mojaapka;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MojaAktywnosc extends Activity {
    private EditText editText1;
    private EditText editText2;
    private TextView tekstTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editTextText);
        editText2 = findViewById(R.id.editTextText2);
        tekstTextView = findViewById(R.id.tekst);

        Button myButton = findViewById(R.id.button);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });
    }

    public void onButtonClick(View view) {
        String tekst1 = editText1.getText().toString();
        String tekst2 = editText2.getText().toString();

        String wynik = "Nazywasz się " + tekst1 + " " + tekst2;

        tekstTextView.setText(wynik);
    }
}
