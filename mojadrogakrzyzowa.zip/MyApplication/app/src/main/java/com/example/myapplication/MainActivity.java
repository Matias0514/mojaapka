package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputEditText;
    private EditText inputEditText2;

    private Button displayButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputEditText = findViewById(R.id.editTextText);
        inputEditText2 = findViewById(R.id.editTextText2);
        displayButton = findViewById(R.id.button);
        resultTextView = findViewById(R.id.tekst);

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tekst1 = inputEditText.getText().toString();
                String tekst2 = inputEditText2.getText().toString();

                String wynik = "Nazywasz się " + tekst1 + " " + tekst2;

                resultTextView.setText(wynik);
            }
        });
    }
}